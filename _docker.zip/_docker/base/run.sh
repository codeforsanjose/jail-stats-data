#!/bin/sh
echo "------START------" >> /dev/stdout
python /_capture/test/test.py
echo "------END--------"