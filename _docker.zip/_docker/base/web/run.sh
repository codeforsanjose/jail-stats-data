#!/bin/sh
python /_web/web.py